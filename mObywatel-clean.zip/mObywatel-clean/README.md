# mObywatel - Polish ID Card Generator

## Setup

1. Create `.env` file from `.env.example`
2. Set DATABASE_URL to your PostgreSQL connection
3. Install dependencies: `pip install -r requirements.txt`
4. Run: `python3 app.py`

## Admin Credentials
- Username: `mamba`
- Password: `MangoMango67`

## Deployment to Railway
1. Push to GitHub
2. Connect Railway to GitHub repo
3. Add DATABASE_URL environment variable
4. Deploy!

## Files
- `gen.html` - Document generator
- `card-view.html` - Document display
- `login.html` - User login
- `admin-login.html` - Admin login
- `app.py` - Flask backend
- `manifest.json` - PWA manifest
